//
//  globalconst.h
//  lec2
//
//  Created by Francisco on 6/28/15.
//  Copyright (c) 2015 Francisco. All rights reserved.
//

#ifndef lec2_globalconst_h
#define lec2_globalconst_h

typedef enum {FALSE=0,TRUE=1} boolean;

#endif
